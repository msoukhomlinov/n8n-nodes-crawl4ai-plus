# crawl4ai/__version__.py

# This is the version that will be used for stable releases
__version__ = "0.7.4"

# For nightly builds, this gets set during build process
__nightly_version__ = None

